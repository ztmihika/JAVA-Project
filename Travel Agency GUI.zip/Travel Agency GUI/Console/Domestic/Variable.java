package Domestic;
public class Variable  {
	protected int cost;
	protected int travel;
	protected int Intravel;
	protected int travelCost;
	protected int Vehicles;
	protected int boat;
	protected int person;
	protected int days;
	protected int bus;
	protected int train;
	protected int plane;
	protected int place;
	protected int hotel;
	protected int hotelcost;
	protected int visit;
	protected int selectPackage;
	protected int selectDestination;
}